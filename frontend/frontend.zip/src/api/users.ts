import type { UserFetchResponse } from '../types/user'

const DEFAULT_API_BASE_URL = 'http://localhost:8000'

export class UserApiError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'UserApiError'
  }
}

function getApiBaseUrl(): string {
  return (import.meta.env.VITE_API_BASE_URL || DEFAULT_API_BASE_URL).replace(/\/$/, '')
}

function getBackendMessage(body: unknown): string | null {
  if (!body || typeof body !== 'object') {
    return null
  }

  const responseBody = body as Record<string, unknown>

  if (typeof responseBody.message === 'string') {
    return responseBody.message
  }

  if (typeof responseBody.detail === 'string') {
    return responseBody.detail
  }

  if (Array.isArray(responseBody.detail)) {
    const firstDetail = responseBody.detail[0]
    if (firstDetail && typeof firstDetail === 'object') {
      const detailMessage = (firstDetail as Record<string, unknown>).msg
      return typeof detailMessage === 'string' ? detailMessage : null
    }
  }

  return null
}

async function getErrorMessage(response: Response): Promise<string> {
  try {
    const body: unknown = await response.json()
    return getBackendMessage(body) ?? 'Não foi possível concluir a consulta.'
  } catch {
    return 'Não foi possível concluir a consulta.'
  }
}

export async function fetchUsers(userIds: number[]): Promise<UserFetchResponse> {
  let response: Response

  try {
    response = await fetch(`${getApiBaseUrl()}/api/users/fetch`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ user_ids: userIds }),
    })
  } catch {
    throw new UserApiError(
      'Não foi possível conectar ao servidor. Verifique sua conexão e tente novamente.',
    )
  }

  if (!response.ok) {
    throw new UserApiError(await getErrorMessage(response))
  }

  try {
    return (await response.json()) as UserFetchResponse
  } catch {
    throw new UserApiError('O servidor retornou uma resposta inválida. Tente novamente.')
  }
}
